"""RORB non-linear storage routing engine.

Routing equations (Laurenson 1964):
    Storage:    S = k * R^m      where R = (I + Q) / 2  (mean reach flow)
    Continuity: S_{t+1} = S_t + dt/2 * (I_t + I_{t+1} - Q_t - Q_{t+1})

Combining and solving for Q_{t+1} via Newton-Raphson:
    f(x) = k * ((I_{t+1} + x)/2)^m + (dt/2)*x - C = 0
    where C = S_t + (dt/2)*(I_t + I_{t+1} - Q_t)

Parameters:
    k  = kc * reach_length_km   [hr * (m³/s)^(1-m)]
    m  = non-linearity exponent (RORB default = 0.8)
    dt = time step               [hours]
    I, Q in m³/s
"""

import numpy as np


def route_rorb(inflow: np.ndarray, k: float, m: float = 0.8, dt: float = 1.0) -> np.ndarray:
    """
    Route an inflow hydrograph through a single reach.

    Args:
        inflow  : upstream flow time series [m³/s]
        k       : reach routing parameter = kc * length_km
        m       : non-linearity exponent (default 0.8)
        dt      : time step [hours]

    Returns:
        outflow : downstream flow time series [m³/s]
    """
    n = len(inflow)
    if n == 0:
        return np.zeros(0)

    outflow = np.zeros(n)
    EPS = 1e-9

    # ── Dry initial condition: S_{-1}=0, Q_{-1}=0, I_{-1}=0 ────────────
    # Solve: k*((I[0]+Q[0])/2)^m + dt/2*Q[0] = dt/2*I[0]
    # This is identical to the inner loop with C = dt/2*I[0], I_curr=I[0].
    C0 = dt / 2.0 * float(inflow[0])
    x = max(0.0, float(inflow[0]) / 2.0)
    for _ in range(150):
        R  = max(EPS, (float(inflow[0]) + x) / 2.0)
        f  = k * (R ** m) + dt / 2.0 * x - C0
        df = k * m * (R ** (m - 1)) * 0.5 + dt / 2.0
        if abs(df) < 1e-30:
            break
        delta = f / df
        x = max(0.0, x - delta)
        if abs(delta) < 1e-10:
            break
    Q_prev  = x
    # S_prev from continuity: S = C - dt/2*Q  (valid whether Q was clamped or not)
    S_prev  = C0 - dt / 2.0 * Q_prev
    outflow[0] = Q_prev

    for t in range(1, n):
        I_prev = float(inflow[t - 1])
        I_curr = float(inflow[t])

        # C from continuity using the correctly tracked S_prev
        C = S_prev + dt / 2.0 * (I_prev + I_curr - Q_prev)

        # Newton-Raphson: f(x) = k*((I_curr+x)/2)^m + (dt/2)*x - C = 0
        x = max(0.0, Q_prev)
        for _ in range(150):
            R  = max(EPS, (I_curr + x) / 2.0)
            f  = k * (R ** m) + dt / 2.0 * x - C
            df = k * m * (R ** (m - 1)) * 0.5 + dt / 2.0
            if abs(df) < 1e-30:
                break
            delta = f / df
            x = max(0.0, x - delta)
            if abs(delta) < 1e-10:
                break

        outflow[t] = x
        Q_prev = x
        # S_prev = C - dt/2*Q  (exact from continuity, handles clamping correctly)
        S_prev = C - dt / 2.0 * x

    return outflow
