import os
import traceback
import numpy as np

from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QGroupBox,
    QLabel, QPushButton, QTextEdit, QTabWidget,
    QWidget, QDoubleSpinBox, QComboBox, QTableWidget, QTableWidgetItem,
    QSplitter, QRadioButton, QButtonGroup, QHeaderView, QFileDialog,
    QMessageBox,
)
from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
from qgis.PyQt.QtGui import QFont, QColor
from qgis.core import QgsMapLayerProxyModel
from qgis.gui import QgsMapLayerComboBox, QgsFieldComboBox

try:
    from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
    from matplotlib.figure import Figure
    HAS_MPL = True
except Exception:
    HAS_MPL = False


class _LayerRow(QHBoxLayout):
    def __init__(self, layer_filter):
        super().__init__()
        self.layer_combo = QgsMapLayerComboBox()
        self.layer_combo.setFilters(layer_filter)
        self.layer_combo.setAllowEmptyLayer(True)
        self.addWidget(self.layer_combo, 3)
        self._fields = {}

    def add_field(self, label, key, allow_empty=False):
        lbl = QLabel(label)
        lbl.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        fc = QgsFieldComboBox()
        fc.setAllowEmptyFieldName(allow_empty)
        self.layer_combo.layerChanged.connect(fc.setLayer)
        fc.setLayer(self.layer_combo.currentLayer())
        self.addWidget(lbl)
        self.addWidget(fc, 2)
        self._fields[key] = fc
        return fc

    def layer(self):
        return self.layer_combo.currentLayer()

    def field(self, key):
        fc = self._fields.get(key)
        return (fc.currentField() or None) if fc else None


class SimWorker(QThread):
    log_msg = pyqtSignal(str)
    finished = pyqtSignal(dict)
    error = pyqtSignal(str)

    def __init__(self, params):
        super().__init__()
        self.params = params

    def run(self):
        try:
            p = self.params
            from .core.qgis_builder import build_reaches, build_confluences, build_basins
            from .core.catchment import Catchment
            from .core.rainfall import (uniform_pattern, triangular_pattern, parse_pattern)
            from .core.simulation import run

            self.log_msg.emit("Building reaches…")
            reaches = build_reaches(p['reach_lyr'], p['fld_rid'],
                                    p['fld_slope'], p['fld_type'])
            self.log_msg.emit(f"  {len(reaches)} reach(es)")

            self.log_msg.emit("Building junctions…")
            confluences = build_confluences(p['junc_lyr'], p['fld_jid'], p['fld_out'])
            outlets = [c for c in confluences if c.isOut]
            self.log_msg.emit(f"  {len(confluences)} junction(s), {len(outlets)} outlet(s)")
            if len(outlets) != 1:
                self.error.emit(f"Need exactly 1 outlet junction (found {len(outlets)}).")
                return

            self.log_msg.emit("Building basins…")
            basins = build_basins(p['cent_lyr'], p['basin_lyr'],
                                  p['fld_cid'], p['fld_fi'])
            self.log_msg.emit(f"  {len(basins)} basin(s), total area "
                              f"{sum(b.area for b in basins):.2f} km²")

            self.log_msg.emit("Connecting topology…")
            catchment = Catchment(confluences, basins, reaches)
            catchment.connect()

            n_steps_storm = max(1, round(p['duration'] / p['dt']))
            if p['rain_mode'] == 'uniform':
                rain = uniform_pattern(p['total_mm'], n_steps_storm)
            elif p['rain_mode'] == 'triangular':
                rain = triangular_pattern(p['total_mm'], n_steps_storm, p['peak_pos'])
            else:
                rain = parse_pattern(p['custom_pattern'], p['total_mm'], n_steps_storm)

            self.log_msg.emit(
                f"Rainfall: {p['total_mm']:.1f} mm over {p['duration']:.1f} hr "
                f"({n_steps_storm} steps × {p['dt']:.2f} hr)"
            )
            self.log_msg.emit("Running simulation…")

            results = run(
                catchment=catchment,
                kc=p['kc'], m=p['m'], dt_hr=p['dt'],
                rainfall_mm=rain,
                loss_model=p['loss_model'],
                il_mm=p['il'], cl_mm_hr=p['cl'],
                prop_loss=p['prop_loss'],
                n_steps=n_steps_storm * 4,
            )

            outlet_peak = next(
                (r['peak_flow'] for r in results.values() if r['is_outlet']), 0.0)
            self.log_msg.emit(f"\nOutlet peak flow: {outlet_peak:.2f} m³/s")
            self.finished.emit(results)

        except Exception:
            self.error.emit(traceback.format_exc())


class RorbModelDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("RORB Builder")
        self.setMinimumSize(960, 720)
        self._results = None
        self._worker = None
        self._build_ui()

    def _build_ui(self):
        root = QVBoxLayout(self)
        self._tabs = QTabWidget()
        self._tabs.addTab(self._tab_catchment(), "Catchment")
        self._tabs.addTab(self._tab_parameters(), "Parameters")
        self._tabs.addTab(self._tab_rainfall(), "Rainfall")
        self._tabs.addTab(self._tab_results(), "Results")
        root.addWidget(self._tabs)

        btn_row = QHBoxLayout()
        self._run_btn = QPushButton("▶  Run Model")
        self._run_btn.setMinimumHeight(38)
        self._run_btn.setDefault(True)
        self._run_btn.clicked.connect(self._on_run)
        catg_btn = QPushButton("Export .catg…")
        catg_btn.setMinimumHeight(38)
        catg_btn.clicked.connect(self._on_export_catg)
        csv_btn = QPushButton("Export CSV…")
        csv_btn.clicked.connect(self._export_csv)
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.close)
        btn_row.addStretch()
        btn_row.addWidget(self._run_btn)
        btn_row.addWidget(catg_btn)
        btn_row.addWidget(csv_btn)
        btn_row.addWidget(close_btn)
        root.addLayout(btn_row)

    def _tab_catchment(self):
        w = QWidget()
        layout = QVBoxLayout(w)
        box = QGroupBox("Input Layers & Field Mapping")
        form = QFormLayout(box)
        form.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)

        self._reach_row = _LayerRow(QgsMapLayerProxyModel.LineLayer)
        self._reach_row.add_field("id:", "id")
        self._reach_row.add_field("type(1-4):", "type", allow_empty=True)
        self._reach_row.add_field("slope:", "slope", allow_empty=True)
        form.addRow("Reaches:", self._reach_row)

        self._cent_row = _LayerRow(QgsMapLayerProxyModel.PointLayer)
        self._cent_row.add_field("id:", "id")
        self._cent_row.add_field("fi [0-1]:", "fi", allow_empty=True)
        form.addRow("Centroids:", self._cent_row)

        self._junc_row = _LayerRow(QgsMapLayerProxyModel.PointLayer)
        self._junc_row.add_field("id:", "id")
        self._junc_row.add_field("outlet(0/1):", "out")
        form.addRow("Confluences:", self._junc_row)

        self._basin_row = _LayerRow(QgsMapLayerProxyModel.PolygonLayer)
        form.addRow("Sub-catchments:", self._basin_row)

        layout.addWidget(box)

        note = QLabel("Reach type: 1=Natural  2=Unlined  3=Lined  4=Drowned  "
                      "(blank → Natural, slope only needed for types 2 & 3)")
        note.setWordWrap(True)
        note.setStyleSheet("color: gray; font-size: 8pt;")
        layout.addWidget(note)

        snap_row = QHBoxLayout()
        snap_row.addWidget(QLabel("Snap tolerance (map units):"))
        self._snap_tol = QDoubleSpinBox()
        self._snap_tol.setRange(0.0, 1000.0)
        self._snap_tol.setValue(1.0)
        self._snap_tol.setDecimals(2)
        self._snap_tol.setSuffix("  m")
        self._snap_tol.setToolTip("Reach endpoints within this distance of a node are snapped to it. Set to 0 to disable.")
        snap_row.addWidget(self._snap_tol)
        snap_row.addStretch()
        layout.addLayout(snap_row)
        layout.addStretch()
        return w

    def _tab_parameters(self):
        w = QWidget()
        layout = QVBoxLayout(w)

        rbox = QGroupBox("RORB Routing Parameters")
        rf = QFormLayout(rbox)
        self._kc = self._spin(0.01, 100.0, 1.0, 3, "hr/km")
        self._m  = self._spin(0.1,   2.0,  0.8, 2, "(dimensionless)")
        rf.addRow("kc (routing coefficient):", self._kc)
        rf.addRow("m  (non-linearity exponent):", self._m)
        tip = QLabel("Typical values: kc = 0.5–5 hr/km for rural Australian catchments. "
                     "m = 0.8 (RORB default).")
        tip.setWordWrap(True)
        tip.setStyleSheet("color: gray; font-size: 8pt;")
        rf.addRow("", tip)
        layout.addWidget(rbox)

        lbox = QGroupBox("Loss Model")
        lf = QFormLayout(lbox)
        self._loss_combo = QComboBox()
        self._loss_combo.addItems(["IL/CL (Initial/Continuing Loss)", "Proportional Loss"])
        self._loss_combo.currentIndexChanged.connect(self._on_loss_changed)
        lf.addRow("Model:", self._loss_combo)
        self._il   = self._spin(0, 500, 25.0, 1, "mm")
        self._cl   = self._spin(0,  50,  2.5, 2, "mm/hr")
        self._prop = self._spin(0,   1,  0.3, 2, "(fraction, 0=no loss, 1=all lost)")
        self._prop.setEnabled(False)
        lf.addRow("Initial loss (IL):", self._il)
        lf.addRow("Continuing loss (CL):", self._cl)
        lf.addRow("Proportional loss fraction:", self._prop)
        layout.addWidget(lbox)

        dtbox = QGroupBox("Time Discretisation")
        dtf = QFormLayout(dtbox)
        self._dt = self._spin(0.01, 24.0, 0.5, 2, "hours")
        dtf.addRow("Time step (dt):", self._dt)
        layout.addWidget(dtbox)
        layout.addStretch()
        return w

    def _tab_rainfall(self):
        w = QWidget()
        layout = QVBoxLayout(w)

        dbox = QGroupBox("Design Storm")
        df = QFormLayout(dbox)
        self._total_mm = self._spin(1, 10000, 100.0, 1, "mm")
        self._duration = self._spin(0.1, 720,   6.0, 1, "hours")
        df.addRow("Total rainfall depth:", self._total_mm)
        df.addRow("Storm duration:", self._duration)
        layout.addWidget(dbox)

        pbox = QGroupBox("Temporal Pattern")
        pf = QFormLayout(pbox)
        self._pattern_group = QButtonGroup(self)
        rb_uniform    = QRadioButton("Uniform (constant intensity)")
        rb_triangular = QRadioButton("Triangular (peak at 1/3)")
        rb_custom     = QRadioButton("Custom (enter values below)")
        rb_uniform.setChecked(True)
        self._pattern_group.addButton(rb_uniform,    0)
        self._pattern_group.addButton(rb_triangular, 1)
        self._pattern_group.addButton(rb_custom,     2)
        self._pattern_group.buttonClicked.connect(self._on_pattern_changed)

        self._peak_pos = self._spin(0.01, 0.99, 0.33, 2, "(fraction of duration)")
        self._peak_pos.setEnabled(False)
        self._custom_pattern = QTextEdit()
        self._custom_pattern.setPlaceholderText(
            "Enter rainfall depths [mm] per time step, comma or space separated.\n"
            "Example (10 steps): 2, 5, 12, 18, 15, 10, 6, 4, 3, 2\n"
            "Will be rescaled to the total depth entered above."
        )
        self._custom_pattern.setMaximumHeight(100)
        self._custom_pattern.setEnabled(False)

        pf.addRow("", rb_uniform)
        pf.addRow("", rb_triangular)
        pf.addRow("Peak position:", self._peak_pos)
        pf.addRow("", rb_custom)
        pf.addRow("Custom pattern:", self._custom_pattern)
        layout.addWidget(pbox)
        layout.addStretch()
        return w

    def _tab_results(self):
        w = QWidget()
        layout = QVBoxLayout(w)

        self._log = QTextEdit()
        self._log.setReadOnly(True)
        self._log.setMaximumHeight(130)
        self._log.setFont(QFont("Courier New", 8))
        layout.addWidget(QLabel("Log:"))
        layout.addWidget(self._log)

        splitter = QSplitter(Qt.Horizontal)
        self._table = QTableWidget(0, 4)
        self._table.setHorizontalHeaderLabels(
            ["Node", "Type", "Peak (m³/s)", "Time to Peak (hr)"])
        self._table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self._table.setEditTriggers(QTableWidget.NoEditTriggers)
        self._table.setMinimumWidth(320)
        splitter.addWidget(self._table)

        if HAS_MPL:
            self._fig = Figure(figsize=(5, 3), tight_layout=True)
            self._ax  = self._fig.add_subplot(111)
            self._canvas = FigureCanvas(self._fig)
            splitter.addWidget(self._canvas)
        else:
            splitter.addWidget(QLabel("(matplotlib not available — install to see chart)"))

        splitter.setSizes([340, 580])
        layout.addWidget(splitter)
        return w

    @staticmethod
    def _spin(lo, hi, val, dec, suffix=""):
        s = QDoubleSpinBox()
        s.setRange(lo, hi)
        s.setValue(val)
        s.setDecimals(dec)
        if suffix:
            s.setSuffix("  " + suffix)
        s.setMinimumWidth(180)
        return s

    def _on_loss_changed(self, idx):
        is_ilcl = (idx == 0)
        self._il.setEnabled(is_ilcl)
        self._cl.setEnabled(is_ilcl)
        self._prop.setEnabled(not is_ilcl)

    def _on_pattern_changed(self, btn):
        mode = self._pattern_group.id(btn)
        self._peak_pos.setEnabled(mode == 1)
        self._custom_pattern.setEnabled(mode == 2)

    def _log_msg(self, msg):
        self._log.append(msg)

    def _validate_layers(self):
        errors = []
        if not self._reach_row.layer():  errors.append("No reach layer selected.")
        if not self._cent_row.layer():   errors.append("No centroid layer selected.")
        if not self._junc_row.layer():   errors.append("No confluence layer selected.")
        if not self._basin_row.layer():  errors.append("No sub-catchment layer selected.")
        if not self._reach_row.field("id"):  errors.append("Reach: id field required.")
        if not self._cent_row.field("id"):   errors.append("Centroid: id field required.")
        if not self._junc_row.field("id"):   errors.append("Confluence: id field required.")
        if not self._junc_row.field("out"):  errors.append("Confluence: outlet field required.")
        return errors

    def _on_run(self):
        self._log.clear()
        self._table.setRowCount(0)
        if HAS_MPL:
            self._ax.clear()
            self._canvas.draw()

        errors = self._validate_layers()
        if errors:
            for e in errors:
                self._log_msg(f"✗ {e}")
            return

        mode_id = self._pattern_group.checkedId()
        pattern_mode = {0: 'uniform', 1: 'triangular', 2: 'custom'}[mode_id]
        if pattern_mode == 'custom' and not self._custom_pattern.toPlainText().strip():
            self._log_msg("✗ Custom pattern: please enter rainfall depths.")
            return

        params = dict(
            reach_lyr=self._reach_row.layer(),
            cent_lyr=self._cent_row.layer(),
            junc_lyr=self._junc_row.layer(),
            basin_lyr=self._basin_row.layer(),
            fld_rid=self._reach_row.field("id"),
            fld_slope=self._reach_row.field("slope"),
            fld_type=self._reach_row.field("type"),
            fld_cid=self._cent_row.field("id"),
            fld_fi=self._cent_row.field("fi"),
            fld_jid=self._junc_row.field("id"),
            fld_out=self._junc_row.field("out"),
            kc=self._kc.value(),
            m=self._m.value(),
            dt=self._dt.value(),
            loss_model='il_cl' if self._loss_combo.currentIndex() == 0 else 'proportional',
            il=self._il.value(),
            cl=self._cl.value(),
            prop_loss=self._prop.value(),
            total_mm=self._total_mm.value(),
            duration=self._duration.value(),
            rain_mode=pattern_mode,
            peak_pos=self._peak_pos.value(),
            custom_pattern=self._custom_pattern.toPlainText(),
        )

        self._run_btn.setEnabled(False)
        self._run_btn.setText("Running…")
        self._tabs.setCurrentIndex(3)

        self._worker = SimWorker(params)
        self._worker.log_msg.connect(self._log_msg)
        self._worker.finished.connect(self._on_finished)
        self._worker.error.connect(self._on_error)
        self._worker.start()

    def _on_finished(self, results):
        self._results = results
        self._run_btn.setEnabled(True)
        self._run_btn.setText("▶  Run Model")
        self._populate_table(results)
        if HAS_MPL:
            self._plot(results)

    def _on_error(self, msg):
        self._run_btn.setEnabled(True)
        self._run_btn.setText("▶  Run Model")
        self._log_msg("ERROR:")
        self._log_msg(msg)

    def _populate_table(self, results):
        rows = sorted(results.values(),
                      key=lambda r: (0 if r['node_type'] == 'Junction' else 1,
                                     -r['peak_flow']))
        self._table.setRowCount(len(rows))
        for i, r in enumerate(rows):
            name_item = QTableWidgetItem(r['name'])
            if r['is_outlet']:
                name_item.setForeground(QColor('#0066cc'))
                font = name_item.font(); font.setBold(True)
                name_item.setFont(font)
            self._table.setItem(i, 0, name_item)
            self._table.setItem(i, 1, QTableWidgetItem(r['node_type']))
            self._table.setItem(i, 2, QTableWidgetItem(f"{r['peak_flow']:.3f}"))
            self._table.setItem(i, 3, QTableWidgetItem(f"{r['time_to_peak']:.2f}"))

    def _plot(self, results):
        self._ax.clear()
        outlet = next((r for r in results.values() if r['is_outlet']), None)
        if outlet:
            self._ax.plot(outlet['time'], outlet['hydro'],
                          color='steelblue', linewidth=2, label='Outlet')
            self._ax.set_xlabel('Time (hr)')
            self._ax.set_ylabel('Flow (m³/s)')
            self._ax.set_title(f"Outlet: {outlet['name']}  "
                               f"Peak = {outlet['peak_flow']:.2f} m³/s")
            self._ax.grid(True, alpha=0.3)
            self._ax.legend()
        self._canvas.draw()

    def _on_export_catg(self):
        errors = self._validate_layers()
        if errors:
            QMessageBox.warning(self, "RORB Builder", "\n".join(errors))
            return

        path, _ = QFileDialog.getSaveFileName(
            self, "Export RORB control file", "", "RORB Control File (*.catg)")
        if not path:
            return

        try:
            import pyromb
            from .vector_layer import QVectorLayer, SnappedQVectorLayer, snap_reach_endpoints

            reach_features = list(self._reach_row.layer().getFeatures())
            conf_features  = list(self._junc_row.layer().getFeatures())
            cent_features  = list(self._cent_row.layer().getFeatures())

            reach_map = {
                'id': self._reach_row.field("id"),
                't':  self._reach_row.field("type"),
                's':  self._reach_row.field("slope"),
            }
            cent_map = {
                'id': self._cent_row.field("id"),
                'fi': self._cent_row.field("fi"),
            }
            conf_map = {
                'id':  self._junc_row.field("id"),
                'out': self._junc_row.field("out"),
            }

            snapped_geoms = snap_reach_endpoints(
                reach_features, [conf_features, cent_features],
                tolerance=self._snap_tol.value())
            reach_vector = SnappedQVectorLayer(reach_features, snapped_geoms, reach_map)
            cent_vector  = QVectorLayer(cent_features,  cent_map)
            conf_vector  = QVectorLayer(conf_features,  conf_map)
            basin_vector = QVectorLayer(self._basin_row.layer())

            builder   = pyromb.Builder()
            tr = builder.reach(reach_vector)
            tc = builder.confluence(conf_vector)
            tb = builder.basin(cent_vector, basin_vector)

            catchment = pyromb.Catchment(tc, tb, tr)
            catchment.connect()
            traveller = pyromb.Traveller(catchment)

            with open(path, 'w') as f:
                f.write(traveller.getVector(pyromb.RORB()))

            QMessageBox.information(self, "RORB Builder", f"Exported successfully:\n{path}")

        except Exception as e:
            QMessageBox.critical(self, "RORB Builder — Export Failed", str(e))

    def _export_csv(self):
        if not self._results:
            self._log_msg("No results to export — run the model first.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Export results", "", "CSV files (*.csv)")
        if not path:
            return
        import csv
        first = next(iter(self._results.values()))
        time = first['time']
        with open(path, 'w', newline='') as f:
            w = csv.writer(f)
            w.writerow(['Node', 'Type', 'Area_km2', 'Peak_m3s', 'TimeToPeak_hr'])
            for r in self._results.values():
                w.writerow([r['name'], r['node_type'],
                             f"{r['area_km2']:.4f}" if r['area_km2'] else '',
                             f"{r['peak_flow']:.4f}",
                             f"{r['time_to_peak']:.3f}"])
            w.writerow([])
            junctions = [r for r in self._results.values()
                         if r['node_type'] == 'Junction']
            w.writerow(['Time_hr'] + [r['name'] for r in junctions])
            for i, t in enumerate(time):
                w.writerow([f"{t:.3f}"] + [f"{r['hydro'][i]:.4f}" for r in junctions])
        self._log_msg(f"Exported to {path}")
